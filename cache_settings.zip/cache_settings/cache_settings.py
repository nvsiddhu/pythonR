# -*- coding: utf-8 -*-

# This settings file is intended for cache settings that can be reused across multiple projects
# such as iqh, moon_pie, and iqh_prod_tools
# The available ports that are currently open are 11600-11749. Other ports needed outside this
# range will require an ACL request to CWx


def create_cache_config(cache_host, cache_connection_timeout, moonpie_theming_version, app='iqh'):

    #caches used accross all four apps (iqh, prod_tools, moonpie, and billpay)
    cache_config = {
        'moonpie.theming': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11626',
            'TIMEOUT': 86400,
            'VERSION': moonpie_theming_version,
        },
        'moonpie.theme_publish_status': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11649',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.domains': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11601',
            'TIMEOUT': 86400,
            'VERSION': '4',
        },

        'iqh.careaware_service_urls': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11625',
            'TIMEOUT': 86400,
            'VERSION': '2',
        },
        'iqh.configurations': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11607',
            'TIMEOUT': 86400,
            'VERSION': '2',
        },
        'iqh.oauth': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11609',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.templates': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11611',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.orgs': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11602',
            'TIMEOUT': 86400,
            'VERSION': '9',
        },
        'iqh.orgs.slug_to_id': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11603',
            'TIMEOUT': 86400,
            'VERSION': '4',
        },
        'iqh.scheduling': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11616',
            'TIMEOUT': 900,
            'VERSION': '1',
        },
        'iqh.scheduling.npa_text_verify': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11676',
            'TIMEOUT': 1800,
            'VERSION': '1',
        },
        'iqh.scheduling_locations': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11668',
            'TIMEOUT': 900,
            'VERSION': '1',
        },
        'django_cache_manager.cache_backend': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11664',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
        'template_fragments': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11669',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.oauth2_token': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11677',
            'TIMEOUT': 300,
            'VERSION': '1',
        },
        'iqh.fhir_metadata': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11678',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
    }

    if app == 'prod_tool':
        #add caches only used by prod_tools
        cache_config.update(_prod_tool_cache_config())
    elif app == 'moonpie':
        #add caches only used by moonpie
        cache_config.update(_moon_pie_cache_config())
    elif app == 'billpay':
        #add caches only used by billpay
        cache_config.update(_billpay_cache_config())

    if app != 'billpay':
        #add caches used by everything but billpay
        cache_config.update(_portal_cache_config())

    #behaviors in value['OPTIONS'] are the same ones cerner health used previously
    #(see, http://scm.healthe-axiom.cerner.corp/svn/axiom-python-services/trunk/axiom_utils/axiom_utils/memcached_wrapper.py).
    #additional behavior options can be found here: http://sendapatch.se/projects/pylibmc/behaviors.html
    for key, value in cache_config.iteritems():
        if key not in ('default', 'staticfiles', 'axiom_django_filez'):
            value['OPTIONS'] = dict(connect_timeout=cache_connection_timeout, hash='murmur', distribution='consistent')
            value['LOCATION'] = [value['LOCATION'].format(host) for host in cache_host]

    return cache_config


def _portal_cache_config():
    '''Cache config for caches only used across iqh, prod_tool, and moonpie.'''
    portal_caches = {
        'default': {
            'BACKEND': "django.core.cache.backends.locmem.LocMemCache",
        },
        'iqh.django_sessions': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11600',
            'TIMEOUT': 1800,
            'VERSION': '1',
        },
        'iqh.labs_history': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11628',
            'TIMEOUT': 1800,
            'VERSION': '1',
        },
        'iqh.labs_event_sets': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11630',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.labs_mill_page_id': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11631',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.labs_data': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11635',
            'TIMEOUT': 300,
            'VERSION': '3',
        },
        'iqh.event_set_hierarchy': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11654',
            'TIMEOUT': 600,
            'VERSION': '1',
        },
        'iqh.persons': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11605',
            'TIMEOUT': 300,
            'VERSION': '1',
        },
        'iqh.person_alias': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11606',
            'TIMEOUT': 300,
            'VERSION': '1',
        },
        'iqh.user_to_org': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11608',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },

        'iqh.ips': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11610',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },

        'iqh.cms': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11612',
            'TIMEOUT': 900,
            'VERSION': '1',
        },
        'moonpie.translations': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11627',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.mobjects_session': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11634',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.users': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11638',
            'TIMEOUT': 86400,
            'VERSION': '4',
        },
        'iqh.user_to_persons': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11639',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
        'iqh.millennium_people': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11640',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
        'iqh.health_record.profile': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11643',
            'TIMEOUT': 3600,
        },
        'staticfiles': {
            'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
            'LOCATION': 'locmem',
            'OPTIONS': {
                'TIMEOUT': 900,
                'MAX_ENTRIES': 500,
                'CULL_FREQUENCIES': 10,
            },
            'VERSION': '1',
        },
        'iqh.messaging': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11642',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.messaging_recipients': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11641',
            'TIMEOUT': 900,
            'VERSION': '1',
        },
        'moonpie.homepage': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11644',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.health_record.procedures': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11645',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.camm.media_attributes': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11648',
            'TIMEOUT': 300,
            'VERSION': '2',
        },
        'iqh.health_record.share_record.direct_message_draft': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11649',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.millennium_names': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11650',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.sso_authorization': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11651',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
        'imh.api_links': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11652',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'imh.encounter_api_links': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11653',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.sso_session_details': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11655',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
        'iqh.wellness_user': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11656',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        #Due to bug 7757, portal and billpay have to use different versions of the oauth.access_tokens cache
        'oauth.access_tokens': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11621',
            'TIMEOUT': 1800,
            'VERSION': '1',
        },
        'iqh.millennium_code_extends': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11657',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.user_to_org_settings': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11659',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.nomenclature_search': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11660',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.infobutton': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11661',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.discretetaskassays': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11662',
            'TIMEOUT': 604800,
            'VERSION': '2',
        },
        'iqh.millennium_code_sets': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11663',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.self_enrollment': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11665',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.millennium_patient': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11666',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.provider_relationship_types': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11667',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.subject_permissions': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11671',
            'TIMEOUT': 1260,
            'VERSION': '1',
        },
        'iqh.service_registrar': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11672',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },

        'iqh.healthe_intent_person_id': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11673',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.mobjects_codes': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11674',
            'TIMEOUT': 3600,
            'VERSION': '1',
        },
        'iqh.emr_family_history': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11675',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.patient_notification_email': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11679',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'iqh.celery_results_backend': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11680',
            'VERSION': '1',
        },
    }

    return portal_caches


def _moon_pie_cache_config():
    '''Cache config for caches only used in moon_pie.'''

    moonpie_caches = {
        'iqh.admin_super_users': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11633',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'moonpie.django_sessions': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11617',
            'TIMEOUT': 900,
            'VERSION': '1',
        },
        'iqh.sso_session_details': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11655',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
    }

    return moonpie_caches


def _prod_tool_cache_config():
    '''Cache config for caches only used in prod_tool.'''

    prodtool_caches = {
        'iqh.admin_super_users': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11633',
            'TIMEOUT': 86400,
            'VERSION': '1',
        },
        'moonpie.django_sessions': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11617',
            'TIMEOUT': 900,
            'VERSION': '1',
        },
        "billpay.access.captcha.counter": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11619",
            'VERSION': '1',
        },
        "billpay.payment.captcha.counter": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11620",
            'VERSION': '1',
        },
        "iqh.payments.account_id_to_facility_id": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11624",
            'VERSION': '1',
        },
        "iqh.payments.facilities": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11622",
            'VERSION': '1',
        },
        "iqh.payments.submitter_id_to_payment_types": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11623",
            'VERSION': '1',
        },
        "iqhtoolz.django_sessions": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11604",
            "TIMEOUT": 28800,
            'VERSION': '1',
        },
        'iqh.sso_session_details': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11655',
            'TIMEOUT': 3600,
            'VERSION': '2',
        },
    }

    return prodtool_caches


def _billpay_cache_config():
    '''Cache config for caches only used in billpay.'''

    billpay_caches = {
        'axiom_django_filez': {
            'BACKEND': 'django.core.cache.backends.filebased.FileBasedCache',
            'LOCATION': '/tmp/axiom_django_filez',
            'TIMEOUT': 60,
            'OPTIONS': {
                'MAX_ENTRIES': 1000
            },
            'VERSION': '1',
        },
        "billpay.access.captcha.counter": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11619",
            'VERSION': '1',
        },
        "billpay.payment.captcha.counter": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11620",
            'VERSION': '1',
        },
        "iqh.payments.account_id_to_facility_id": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11624",
            'VERSION': '1',
        },
        "iqh.payments.facilities": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11622",
            'VERSION': '1',
        },
        "iqh.payments.submitter_id_to_payment_types": {
            "BACKEND": "personal_health_django_cache.custom.backend.memcached.PyLibMCCache",
            "LOCATION": "{0}:11623",
            'VERSION': '2',
        },
        # Long cache timeout for staticfiles, since this is used heavily by the optimizing storage.
        "staticfiles": {
            "BACKEND": "django.core.cache.backends.locmem.LocMemCache",
            "TIMEOUT": 60 * 60 * 24 * 365,
            "LOCATION": "staticfiles",
            "VERSION": "1",
        },
        #Due to bug 7757, portal and billpay have to use different versions of the oauth.access_tokens cache
        'oauth.access_tokens': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11621',
            'TIMEOUT': None,
            'VERSION': '3',
        },
        # Override iqh.orgs to add timeout for billpay orgs
        'iqh.orgs': {
            'BACKEND': 'personal_health_django_cache.custom.backend.memcached.PyLibMCCache',
            'LOCATION': '{0}:11602',
            'TIMEOUT': 450,
            'VERSION': '8',
        },
    }

    return billpay_caches
